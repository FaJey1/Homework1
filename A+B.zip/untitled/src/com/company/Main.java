package com.company;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        int a,b,c;
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите первое число");
        a= sc.nextInt();
        System.out.println("Введите второе число");
        b= sc.nextInt();
        c=a+b;
        System.out.println("Сумма чисел "+ a + " и "+ b + " равна " + c);
    }
}
